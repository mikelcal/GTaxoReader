# GTaxoReader
A tool to quickly search the Google Product Taxonomy built using open source JQuery pugins and unphazed determination

Featuring:
* UI by Twitter [Bootstrap](http://getbootstrap.com/)
* Table Pagination et al by [Data Tables](http://www.datatables.net/)
* Search Highlighting by [JQuery.Highlight.js](https://github.com/bartaz/sandbox.js)
* Google Product Taxonomy Version 2013-12-12  
